const sharp = require('sharp');
const path = require('path');

const images = [
    'illustration-du-logo-du-symbole-dommages-causes-par-inondations_337180-947.jpg',
    'png-clipart-algiers-alger-centre-organization-city-sarl-mgsd-alger-city-logo.png'
];

async function convertToAvif() {
    for (const image of images) {
        const inputPath = path.join(__dirname, 'assets', 'images', image);
        const outputPath = path.join(__dirname, 'assets', 'images', `${path.parse(image).name}.avif`);
        
        try {
            await sharp(inputPath)
                .avif({
                    quality: 80,
                    effort: 9
                })
                .toFile(outputPath);
            console.log(`Converted ${image} to AVIF`);
        } catch (error) {
            console.error(`Error converting ${image}:`, error);
        }
    }
}

convertToAvif();
