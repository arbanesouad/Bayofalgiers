import {
    processAnnualData,
    processMonthlyData,
    calculateMonthlyAverages,
    calculateQuinquennialAverages
} from './data.js';

// Variables pour stocker les graphiques
let annualPrecipChart = null;
let monthlyPrecipChart = null;
let timelinePrecipChart = null;
let quinquennialPrecipChart = null;

// Couleurs pour les graphiques
const chartColors = {
    primary: 'rgba(54, 162, 235, 0.8)',
    secondary: 'rgba(255, 99, 132, 0.8)',
    tertiary: 'rgba(75, 192, 192, 0.8)',
    quaternary: 'rgba(153, 102, 255, 0.8)'
};

// Initialisation des graphiques
async function initCharts() {
    const annualData = await processAnnualData();
    const monthlyData = await processMonthlyData();
    const monthlyAverages = calculateMonthlyAverages(monthlyData);
    const quinquennialData = calculateQuinquennialAverages(annualData);

    createAnnualPrecipChart(annualData);
    createMonthlyPrecipChart(monthlyAverages);
    createTimelinePrecipChart(monthlyData);
    createQuinquennialPrecipChart(quinquennialData);

    // Ajouter les écouteurs d'événements pour les boutons
    document.querySelectorAll('.chart-toggle').forEach(button => {
        button.addEventListener('click', () => toggleChart(button.dataset.chart));
    });

    // Afficher le graphique annuel par défaut
    toggleChart('annual');
}

// Fonctions de création des graphiques
function createAnnualPrecipChart(data) {
    const ctx = document.getElementById('annual-precip-chart').getContext('2d');
    annualPrecipChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.year),
            datasets: [{
                label: 'Précipitation Annuelle (mm)',
                data: data.map(d => d.precip_mm),
                backgroundColor: chartColors.primary
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Précipitations Annuelles (2000-2022)'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Précipitations (mm)'
                    }
                }
            }
        }
    });
}

function createMonthlyPrecipChart(data) {
    const ctx = document.getElementById('monthly-precip-chart').getContext('2d');
    const monthNames = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
    
    monthlyPrecipChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: monthNames,
            datasets: [{
                label: 'Moyenne Mensuelle (mm)',
                data: data.map(d => d.precip_mm),
                borderColor: chartColors.secondary,
                fill: false,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Moyenne Mensuelle des Précipitations'
                }
            }
        }
    });
}

function createTimelinePrecipChart(data) {
    const ctx = document.getElementById('timeline-precip-chart').getContext('2d');
    const monthNames = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
    
    timelinePrecipChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => `${monthNames[d.month-1]} ${d.year}`),
            datasets: [{
                label: 'Précipitations (mm)',
                data: data.map(d => d.precip_mm),
                borderColor: chartColors.tertiary,
                fill: false,
                pointRadius: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Évolution Temporelle des Précipitations'
                }
            }
        }
    });
}

function createQuinquennialPrecipChart(data) {
    const ctx = document.getElementById('quinquennial-precip-chart').getContext('2d');
    
    quinquennialPrecipChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.period),
            datasets: [{
                label: 'Moyenne Quinquennale (mm)',
                data: data.map(d => d.precip_mm),
                backgroundColor: chartColors.quaternary
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Moyennes Quinquennales des Précipitations'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Précipitations (mm)'
                    }
                }
            }
        }
    });
}

// Fonction pour basculer entre les graphiques
function toggleChart(chartType) {
    const charts = {
        'annual': document.getElementById('annual-precip-chart'),
        'monthly': document.getElementById('monthly-precip-chart'),
        'timeline': document.getElementById('timeline-precip-chart'),
        'quinquennial': document.getElementById('quinquennial-precip-chart')
    };

    // Cacher tous les graphiques
    Object.values(charts).forEach(chart => {
        chart.style.display = 'none';
    });

    // Afficher le graphique sélectionné
    charts[chartType].style.display = 'block';

    // Mettre à jour le bouton actif
    document.querySelectorAll('.chart-toggle').forEach(button => {
        button.classList.toggle('active', button.dataset.chart === chartType);
    });
}

// Exporter les fonctions
export { initCharts };
